import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Iterator;

import org.apache.http.client.ClientProtocolException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

public class GetRestResponse {
	 
	 public static void main(String[] args) throws ClientProtocolException, IOException {
		 
		 URL url = null;
		 
			try {
			Workbook workbook = WorkbookFactory.create(new File(args[0]));
			Sheet sheet = workbook.getSheetAt(0);
			 DataFormatter dataFormatter = new DataFormatter();
			 Iterator<Row> rowIterator = sheet.rowIterator();
			 
			 ByteArrayOutputStream out = new ByteArrayOutputStream();
			 Row row = rowIterator.next();
			 while (rowIterator.hasNext()) {
		            row = rowIterator.next();

		            
		            Iterator<Cell> cellIterator = row.cellIterator();

		            if (cellIterator.hasNext()) {
		                Cell cell = cellIterator.next();
		                String cellValue = dataFormatter.formatCellValue(cell);
		                if(cellValue!=null && cellValue.length() > 0) {
		                	url = new URL(cellValue);
		                
				 String output;
				
			
				 HttpURLConnection conn = (HttpURLConnection) url.openConnection();
				 conn.setRequestMethod("GET");
					conn.setRequestProperty("Accept", "application/json");
				if (conn.getResponseCode() != 200) {
					
					BufferedReader br = new BufferedReader(new InputStreamReader(
							(conn.getErrorStream())));
					while ((output = br.readLine()) != null) {
						JSONParser parser = new JSONParser(); 
						JSONObject json;
						json = (JSONObject) parser.parse(output);
						Cell statusCell = row.createCell(cell.getColumnIndex()+1);
						statusCell.setCellValue(json.get("status").toString());
						Cell messageCell = row.createCell(cell.getColumnIndex()+2);
						messageCell.setCellValue(json.get("message").toString());
						Cell errorCell = row.createCell(cell.getColumnIndex()+3);
						errorCell.setCellValue(json.get("error").toString());
					}
					
				}
				else {
				
					BufferedReader br = new BufferedReader(new InputStreamReader(
						(conn.getInputStream())));
					StringBuffer strBuf = new StringBuffer();
					while ((output = br.readLine()) != null) {
						strBuf.append(output);
					}
						Cell statusCell = row.createCell(cell.getColumnIndex()+1);
						statusCell.setCellValue(conn.getResponseCode());
						Cell errorCell = row.createCell(cell.getColumnIndex()+2);
						errorCell.setCellValue(strBuf.toString());
				}
				workbook.write(out);
				conn.disconnect();
				}
		            }
		            }
			 workbook.close();
				}
				  catch (ParseException e) {
						e.printStackTrace();
					}
				catch (Exception e1) {
					e1.printStackTrace();
				} 
				
		 }

}
